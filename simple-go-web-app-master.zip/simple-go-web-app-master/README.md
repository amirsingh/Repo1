## Build the app
```
go build main.go
```
## Run the app
```
./main
```

or 

```
go run main.go
```